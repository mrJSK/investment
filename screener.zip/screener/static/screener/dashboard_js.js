let allIndicators = [];
let filterCount = 0;
let activeInput = null;

// Fetch indicators on page load
fetch("/screener/api/indicators/")
  .then((resp) => resp.json())
  .then((data) => {
    allIndicators = [
      { value: "open", label: "Open" },
      { value: "high", label: "High" },
      { value: "low", label: "Low" },
      { value: "close", label: "Close" },
      { value: "volume", label: "Volume" },
      ...data.indicators,
    ];
    renderIndicators("");
  });

function renderIndicators(filter = "") {
  const list = document.getElementById("indicatorList");
  list.innerHTML = "";
  // Add a value entry option (for right side)
  if (activeInput && activeInput.classList.contains("right-indicator")) {
    const valueLi = document.createElement("li");
    valueLi.className = "list-group-item list-group-item-action";
    valueLi.style.cursor = "pointer";
    valueLi.textContent = "Enter Value…";
    valueLi.onclick = () => selectValueEntry();
    list.appendChild(valueLi);
  }
  allIndicators
    .filter((i) => i.label.toLowerCase().includes(filter.toLowerCase()))
    .forEach((indicator) => {
      const li = document.createElement("li");
      li.className = "list-group-item list-group-item-action";
      li.style.cursor = "pointer";
      li.textContent = indicator.label;
      li.onclick = () => selectIndicator(indicator.value);
      list.appendChild(li);
    });
}

// Add a modal for indicator parameters
function showIndicatorParamsModal(indicatorValue, onSubmit) {
  fetch(`/screener/api/indicator_params/?fn=${indicatorValue}`)
    .then((resp) => resp.json())
    .then((data) => {
      let formHtml = "";
      if (data.params && data.params.length) {
        data.params.forEach((param) => {
          if (param.type === "series") {
            formHtml += `<label>${param.name}</label>
              <select class="form-select mb-2" name="${param.name}">
                <option value="close">Close</option>
                <option value="open">Open</option>
                <option value="high">High</option>
                <option value="low">Low</option>
                <option value="volume">Volume</option>
              </select>`;
          } else {
            formHtml += `<label>${param.name}</label>
              <input class="form-control mb-2" name="${
                param.name
              }" type="number" value="${
              param.default !== null ? param.default : ""
            }" />`;
          }
        });
      }
      const paramModal = document.createElement("div");
      paramModal.className = "modal fade";
      paramModal.id = "indicatorParamsModal";
      paramModal.tabIndex = -1;
      paramModal.innerHTML = `
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Indicator Parameters</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="paramForm">
              <div class="modal-body">
                ${formHtml}
              </div>
              <div class="modal-footer">
                <button type="submit" class="btn btn-primary">OK</button>
              </div>
            </form>
          </div>
        </div>
      `;
      document.body.appendChild(paramModal);
      const bsModal = new bootstrap.Modal(paramModal);
      bsModal.show();

      paramModal.querySelector("#paramForm").onsubmit = function (e) {
        e.preventDefault();
        const formData = new FormData(this);
        const paramStr = Array.from(formData.entries())
          .map(([k, v]) => v)
          .join(", ");
        onSubmit(`${indicatorValue}(${paramStr})`);
        bsModal.hide();
        setTimeout(() => paramModal.remove(), 500);
      };
      paramModal.querySelector(".btn-close").onclick = function () {
        bsModal.hide();
        setTimeout(() => paramModal.remove(), 500);
      };
    });
}

// ==== Filter row template with identifiable classes ====
function newConditionRow(idx = 0) {
  return `
<div class="filter-card px-3 py-2 mb-2 d-flex align-items-center flex-wrap rounded shadow-sm bg-white gap-2 condition-row">
  <span class="filter-index badge bg-light text-secondary" style="font-size:1em;">[${idx}]</span>
  <input type="text" class="form-control indicator-select left-indicator" style="width:130px;cursor:pointer" placeholder="Indicator" readonly>
  <select class="form-select mx-2" style="width:80px">
    <option value=">">&gt;</option>
    <option value="<">&lt;</option>
    <option value=">=">&ge;</option>
    <option value="<=">&le;</option>
    <option value="==">=</option>
  </select>
  <input type="text" class="form-control indicator-select right-indicator" style="width:130px;cursor:pointer" placeholder="Indicator/Value" readonly>
  <input type="text" class="form-control ms-1" style="width:90px" placeholder="Constant">
  <select class="form-select mx-2" style="width:80px">
    <option value="AND">AND</option>
    <option value="OR">OR</option>
  </select>
  <button class="icon-btn remove-condition" type="button" title="Remove"><span>❌</span></button>
  <button class="icon-btn" type="button" title="Copy"><span>📋</span></button>
  <button class="icon-btn" type="button" title="Explain"><span>❓</span></button>
</div>
`;
}

function refreshIndices() {
  document.querySelectorAll("#conditions .filter-card").forEach((row, i) => {
    row.querySelector(".filter-index").textContent = `[${i}]`;
  });
}
function addConditionRow() {
  let container = document.getElementById("conditions");
  container.insertAdjacentHTML("beforeend", newConditionRow(filterCount));
  filterCount++;
  refreshIndices();
  bindFilterEvents();
}
function bindFilterEvents() {
  document.querySelectorAll(".remove-condition").forEach((btn) => {
    btn.onclick = function () {
      this.closest(".condition-row").remove();
      refreshIndices();
      filterCount = document.querySelectorAll(
        "#conditions .filter-card"
      ).length;
    };
  });
  document.querySelectorAll(".indicator-select").forEach((el) => {
    el.onclick = function () {
      activeInput = this;
      renderIndicators("");
      let modal = new bootstrap.Modal(
        document.getElementById("indicatorModal")
      );
      modal.show();
    };
  });
}
document.getElementById("addFilter").onclick = addConditionRow;
addConditionRow(); // One filter row on load

// ==== INDICATOR PICKER MODAL ====
document
  .getElementById("indicatorSearch")
  .addEventListener("input", function () {
    renderIndicators(this.value);
  });

function selectIndicator(indicatorValue) {
  // Find the label for display
  const indicatorObj = allIndicators.find((i) => i.value === indicatorValue);
  fetch(`/screener/api/indicator_params/?fn=${indicatorValue}`)
    .then((resp) => resp.json())
    .then((data) => {
      if (data.params && data.params.length) {
        showIndicatorParamsModal(indicatorValue, (label) => {
          if (activeInput) activeInput.value = label;
        });
      } else {
        if (activeInput)
          activeInput.value = indicatorObj
            ? indicatorObj.label
            : indicatorValue;
      }
      let modal = bootstrap.Modal.getInstance(
        document.getElementById("indicatorModal")
      );
      modal.hide();
    });
}
function selectValueEntry() {
  if (activeInput) {
    // Turn this input into a number input temporarily
    const val = prompt("Enter value (e.g. 60):");
    activeInput.value = val || "";
  }
  let modal = bootstrap.Modal.getInstance(
    document.getElementById("indicatorModal")
  );
  modal.hide();
}
renderIndicators("");
