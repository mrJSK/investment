// Screener Builder (Dynamic TA-Lib indicators from Django backend)

let INDICATORS = [];
let INDICATOR_GROUPS = {}; // { group_name: [{ value, label }], ... }
const FIELDS = ["Open", "High", "Low", "Close", "Volume"];
const TIMEFRAMES = ["Daily", "Weekly", "15min"];
const OPERATORS = [">", "<", ">=", "<=", "crosses above", "crosses below"];
const RIGHT_TYPES = [
  { value: "number", label: "Number" },
  { value: "indicator", label: "Indicator" },
];

let filterId = 0;
let filters = [];

// Fetch all TA-Lib indicators from backend API
function fetchIndicatorsAndRender() {
  fetch("/api/indicators/")
    .then((res) => res.json())
    .then((data) => {
      INDICATOR_GROUPS = data.groups;
      INDICATORS = Object.values(INDICATOR_GROUPS).flat();
      renderFilters();
    });
}
fetchIndicatorsAndRender();

// Helper: Render indicator dropdown with groups
function renderIndicatorDropdown(selected) {
  let html = "";
  for (const [group, items] of Object.entries(INDICATOR_GROUPS)) {
    html += `<optgroup label="${group}">`;
    for (const ind of items) {
      html += `<option value="${ind.value}" ${
        selected === ind.value ? "selected" : ""
      }>${ind.label}</option>`;
    }
    html += `</optgroup>`;
  }
  return html;
}

// Render All Filter Rows
function renderFilters() {
  const filterList = document.getElementById("filter-list");
  filterList.innerHTML = "";
  filters.forEach((f, idx) => {
    filterList.appendChild(renderFilterRow(f, idx));
  });
}

// Render a Single Filter Row
function renderFilterRow(f, idx) {
  const row = document.createElement("div");
  row.className = "row align-items-center mb-2 filter-row";
  row.dataset.idx = idx;

  row.innerHTML += `
    <div class="col-auto">
      <select class="form-select form-select-sm timeframe-select">
        ${TIMEFRAMES.map(
          (tf) =>
            `<option ${f.timeframe === tf ? "selected" : ""}>${tf}</option>`
        ).join("")}
      </select>
    </div>
    <div class="col-auto">
      <select class="form-select form-select-sm indicator-select">
        <option value="">Indicator</option>
        ${renderIndicatorDropdown(f.indicator)}
      </select>
    </div>
    <div class="col-auto">
      <span>(</span>
      <select class="form-select form-select-sm timeframe2-select d-inline w-auto">
        ${TIMEFRAMES.map(
          (tf) =>
            `<option ${f.timeframe2 === tf ? "selected" : ""}>${tf}</option>`
        ).join("")}
      </select>
      <select class="form-select form-select-sm field-select d-inline w-auto">
        ${FIELDS.map(
          (field) =>
            `<option ${f.field === field ? "selected" : ""}>${field}</option>`
        ).join("")}
      </select>
      <input type="number" class="form-control form-control-sm period-input d-inline w-auto" value="${
        f.period
      }" style="width:60px;display:inline;" min="1">
      <span>)</span>
    </div>
    <div class="col-auto">
      <select class="form-select form-select-sm main-op-select d-inline w-auto">
        ${OPERATORS.map(
          (op) => `<option ${f.mainOp === op ? "selected" : ""}>${op}</option>`
        ).join("")}
      </select>
    </div>
    <div class="col-auto">
      <select class="form-select form-select-sm right-type-select d-inline w-auto">
        ${RIGHT_TYPES.map(
          (rt) =>
            `<option value="${rt.value}" ${
              f.rightType === rt.value ? "selected" : ""
            }>${rt.label}</option>`
        ).join("")}
      </select>
    </div>
    <div class="col-auto right-side">
      ${
        f.rightType === "number"
          ? `
        <input type="number" class="form-control form-control-sm right-number-input d-inline w-auto" value="${f.rightValue}" style="width:80px;">
      `
          : `
        <select class="form-select form-select-sm right-indicator-select d-inline w-auto">
          <option value="">Indicator</option>
          ${renderIndicatorDropdown(f.rightIndicator)}
        </select>
        <input type="number" class="form-control form-control-sm right-period-input d-inline w-auto" value="${
          f.rightPeriod || 14
        }" style="width:60px;">
      `
      }
    </div>
    <div class="col-auto">
      <button class="btn btn-outline-danger btn-sm remove-filter-btn">✕</button>
    </div>
  `;

  setTimeout(() => {
    row.querySelector(".timeframe-select").onchange = (e) =>
      updateFilter(idx, { timeframe: e.target.value });
    row.querySelector(".indicator-select").onchange = (e) =>
      updateFilter(idx, { indicator: e.target.value });
    row.querySelector(".timeframe2-select").onchange = (e) =>
      updateFilter(idx, { timeframe2: e.target.value });
    row.querySelector(".field-select").onchange = (e) =>
      updateFilter(idx, { field: e.target.value });
    row.querySelector(".period-input").oninput = (e) =>
      updateFilter(idx, { period: e.target.value });
    row.querySelector(".main-op-select").onchange = (e) =>
      updateFilter(idx, { mainOp: e.target.value });
    row.querySelector(".right-type-select").onchange = (e) =>
      updateFilter(idx, { rightType: e.target.value });
    if (f.rightType === "number") {
      row.querySelector(".right-number-input").oninput = (e) =>
        updateFilter(idx, { rightValue: e.target.value });
    } else {
      row.querySelector(".right-indicator-select").onchange = (e) =>
        updateFilter(idx, { rightIndicator: e.target.value });
      row.querySelector(".right-period-input").oninput = (e) =>
        updateFilter(idx, { rightPeriod: e.target.value });
    }
    row.querySelector(".remove-filter-btn").onclick = () => removeFilter(idx);
  }, 0);

  return row;
}

// Update Filter in State
function updateFilter(idx, patch) {
  filters[idx] = { ...filters[idx], ...patch };
  renderFilters();
}

// Remove a Filter
function removeFilter(idx) {
  filters.splice(idx, 1);
  renderFilters();
}

// Add Filter Button
document.getElementById("add-filter-btn").onclick = function () {
  filters.push({
    id: ++filterId,
    timeframe: "Daily",
    indicator: "",
    timeframe2: "Daily",
    field: "Close",
    period: 20,
    mainOp: ">=",
    rightType: "number",
    rightValue: 20,
    rightIndicator: "",
    rightPeriod: 14,
  });
  renderFilters();
};

// Submit Form (Run Screener)
document.getElementById("screener-form").onsubmit = function (e) {
  e.preventDefault();
  fetch("/api/run_screener/", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ filters }),
  })
    .then((res) => res.json())
    .then((data) => {
      document.getElementById("screener-results").innerHTML = `
        <div class="alert alert-info">Matched Stocks:<br>${data.matches.join(
          ", "
        )}</div>
      `;
    });
  return false;
};

// Initial render (empty)
renderFilters();
